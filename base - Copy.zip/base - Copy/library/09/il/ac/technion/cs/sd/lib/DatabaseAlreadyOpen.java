package il.ac.technion.cs.sd.lib;

public class DatabaseAlreadyOpen extends Exception {
}
