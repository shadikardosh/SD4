package il.ac.technion.cs.sd.lib;


public class NoSuchDatabaseOpen extends Exception {
}
